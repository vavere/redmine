require File.expand_path('../../../redmine_testing_gems/spec_helper', __FILE__)
